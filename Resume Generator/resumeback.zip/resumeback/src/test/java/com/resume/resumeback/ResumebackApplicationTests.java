package com.resume.resumeback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumebackApplicationTests {

	@Test
	void contextLoads() {
	}

}
