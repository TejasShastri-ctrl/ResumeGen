package com.resume.resumeback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumebackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumebackApplication.class, args);
	}

}
